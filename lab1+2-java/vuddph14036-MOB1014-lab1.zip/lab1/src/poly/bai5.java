package poly;

import java.util.Scanner;

public class bai5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name;
        double weight;
        int age;

        System.out.println("Nhập Name: ");
        name =sc.nextLine();
        System.out.println("Nhập weight: ");
        weight = sc.nextDouble();
        System.out.println("Nhập Age: ");
        age = sc.nextInt();


        System.out.println("Name: "+ name);
        System.out.printf("weight: %.2f\n", weight);
        System.out.println("Age: " + age);
    }


}
