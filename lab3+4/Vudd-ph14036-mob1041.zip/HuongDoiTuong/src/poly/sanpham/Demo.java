package poly.sanpham;

public class Demo {
    public static void main(String[] args) {
        SanPham sp1 = new SanPham("quạt điện",500,45);
        System.out.println(sp1);

        SanPham sp = new SanPham();
        sp.input();
        System.out.println(sp.toString());
    }
}
