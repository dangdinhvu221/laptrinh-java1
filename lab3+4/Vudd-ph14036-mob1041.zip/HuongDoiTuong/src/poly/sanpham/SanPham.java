package poly.sanpham;

import java.util.Scanner;

public class SanPham {
    static Scanner sc = new Scanner(System.in);
     String name;
    double price;
    double weight;

    public SanPham() {

    }

    public SanPham(String name, double price, double weight) {
        this.name = name;
        this.price = price;
        this.weight = weight;
    }

    public void input(){
        System.out.println("Nhập tên SP: ");
        name = sc.nextLine();
        System.out.println("Nhập giá: ");
        price = Double.parseDouble(sc.nextLine());
        System.out.println("Nhập cân nặng: ");
        weight = Double.parseDouble(sc.nextLine());
    }

    public String getStatus(double price){
        if (price < 200){
           return "giá rẻ";
        }else if (price < 500){
            return "trung bình";
        }else {
            return "quá đắt";
        }
    }

    @Override
    public String toString() {
        return "SanPham{" +
                "name= '" + name + '\'' +
                ", price= " + price +
                ", weight= " + weight + "Status: " + getStatus(price) +
                '}';
    }
}
