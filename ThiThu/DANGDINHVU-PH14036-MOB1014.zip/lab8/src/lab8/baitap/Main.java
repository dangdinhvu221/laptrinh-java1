package lab8.baitap;

public class Main {
    public static void main(String[] args) {
        System.out.println("Sum: " + XPoly.sum(8,9));

        System.out.println("Min: "+ XPoly.min(5,10,6,15));
        System.out.println("Min: "+ XPoly.max(5,10,6,15));

        XPoly.toUpperFistChars("duc an lon");
    }
}
